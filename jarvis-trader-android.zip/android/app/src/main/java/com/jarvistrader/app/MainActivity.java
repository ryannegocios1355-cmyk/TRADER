package com.jarvistrader.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
