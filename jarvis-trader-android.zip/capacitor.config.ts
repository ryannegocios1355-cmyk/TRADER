import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.jarvistrader.app',
  appName: 'Jarvis Trader',
  webDir: 'dist'
};

export default config;
