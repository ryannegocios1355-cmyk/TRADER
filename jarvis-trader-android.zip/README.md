# Jarvis Trader — App Android

Dashboard de análise técnica (RSI, MACD, EMA) com dados em tempo real da Twelve Data,
empacotado como app Android nativo via Capacitor.

## Como gerar o APK (sem precisar instalar Android Studio)

Este projeto já vem com um workflow do GitHub Actions (`.github/workflows/build-apk.yml`)
que compila o `.apk` automaticamente na nuvem, com o Android SDK já pronto.

### Passo a passo

1. **Crie uma conta gratuita no GitHub** (se ainda não tiver): https://github.com/signup

2. **Crie um repositório novo**:
   - No GitHub, clique em "New repository"
   - Dê um nome (ex: `jarvis-trader`)
   - Deixe como **privado** (recomendado, já que o projeto contém sua API key)
   - Crie o repositório vazio (sem README)

3. **Suba os arquivos deste projeto para o repositório.**
   - Mais fácil (sem usar terminal): na página do repositório, clique em
     "uploading an existing file" e arraste todos os arquivos e pastas desta pasta
     (exceto `node_modules` e `dist`, que não são necessários).
   - Ou via terminal, dentro desta pasta:
     ```
     git init
     git add .
     git commit -m "primeiro commit"
     git branch -M main
     git remote add origin https://github.com/SEU_USUARIO/jarvis-trader.git
     git push -u origin main
     ```

4. **O build inicia automaticamente** assim que você sobe os arquivos (aba "Actions"
   do repositório). Se não iniciar sozinho, vá em Actions → "Build Android APK" →
   "Run workflow".

5. **Aguarde uns 3-5 minutos.** Quando o workflow terminar (ícone verde ✓), clique
   nele, role até "Artifacts" e baixe `jarvis-trader-apk` — é um .zip contendo o
   `app-debug.apk`.

6. **Instale no seu celular Android:**
   - Transfira o `.apk` pro celular (Google Drive, WhatsApp Web, cabo USB, etc.)
   - Abra o arquivo no celular
   - Se aparecer aviso de "fontes desconhecidas", vá em Configurações > Segurança
     e permita instalação desse app/navegador
   - Toque em Instalar

Pronto — o ícone "Jarvis Trader" aparece na sua tela inicial como qualquer outro app.

## Sobre a API key

A chave da Twelve Data está pré-preenchida no app, mas fica salva apenas no
armazenamento local do próprio celular (não é enviada a nenhum servidor além da
Twelve Data). Você pode trocá-la a qualquer momento no ícone de engrenagem dentro
do app.

## Atualizando o app depois

Sempre que quiser mudar algo no código (`src/App.jsx`), suba a alteração pro mesmo
repositório (`git push` ou novo upload) — o workflow gera um novo APK automaticamente.
Para instalar a atualização, baixe o novo APK e instale por cima do anterior.

## Rodar localmente no navegador (sem celular)

```
npm install
npm run dev
```
