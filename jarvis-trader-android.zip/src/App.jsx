import { useState, useEffect, useCallback, useRef } from "react";
import {
  TrendingUp, TrendingDown, Minus, RefreshCw, Clock, BookOpen,
  AlertTriangle, ChevronDown, ChevronUp, Wifi, WifiOff, Settings2, X
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ComposedChart, Bar, ReferenceLine
} from "recharts";

const C = {
  bg: "#0A0D12",
  panel: "#11151C",
  panel2: "#161B24",
  border: "#222834",
  text: "#E7EAEE",
  muted: "#8B95A5",
  buy: "#1FD17A",
  sell: "#FF5C5C",
  wait: "#E8B339",
  accent: "#3DA8FF",
};

const ASSETS = [
  { symbol: "BTC/USD", label: "Bitcoin", category: "Cripto", broker: "Ebinex · M1", payout: 90 },
  { symbol: "ETH/USD", label: "Ethereum", category: "Cripto", broker: "Ebinex · M1", payout: 90 },
  { symbol: "SOL/USD", label: "Solana", category: "Cripto", broker: "Ebinex · M1", payout: 90 },
  { symbol: "XRP/USD", label: "Ripple", category: "Cripto", broker: "Ebinex · M1", payout: 90 },
  { symbol: "ADA/USD", label: "Cardano", category: "Cripto", broker: "Ebinex · M1", payout: 90 },
  { symbol: "DOGE/USD", label: "Dogecoin", category: "Cripto", broker: "Ebinex · M1", payout: 90 },
  { symbol: "NZD/CAD", label: "NZD/CAD", category: "Forex", broker: "Olymptrade · OTC~", payout: 85 },
  { symbol: "NZD/CHF", label: "NZD/CHF", category: "Forex", broker: "Olymptrade · OTC~", payout: 85 },
  { symbol: "NZD/JPY", label: "NZD/JPY", category: "Forex", broker: "Olymptrade · OTC~", payout: 85 },
  { symbol: "NZD/USD", label: "NZD/USD", category: "Forex", broker: "Olymptrade · OTC~", payout: 85 },
  { symbol: "USD/CAD", label: "USD/CAD", category: "Forex", broker: "Olymptrade · OTC~", payout: 85 },
  { symbol: "USD/CHF", label: "USD/CHF", category: "Forex", broker: "Olymptrade · OTC~", payout: 85 },
  { symbol: "AUD/USD", label: "AUD/USD", category: "Forex", broker: "Olymptrade · OTC~", payout: 80 },
  { symbol: "USD/JPY", label: "USD/JPY", category: "Forex", broker: "Olymptrade · OTC~", payout: 80 },
  { symbol: "XAG/USD", label: "Prata (Silver)", category: "Commodities", broker: "Olymptrade · OTC~", payout: 85 },
];

const INTERVALS = [
  { value: "1min", label: "M1", mins: 1 },
  { value: "5min", label: "M5", mins: 5 },
  { value: "15min", label: "M15", mins: 15 },
];

const KNOWLEDGE = {
  rsi: { title: "RSI — Índice de Força Relativa", text: "Mede a velocidade das variações de preço numa escala de 0 a 100. Acima de 70 sugere sobrecompra; abaixo de 30 sugere sobrevenda. Funciona melhor em mercados com algum range e pode falhar em tendências fortes." },
  macd: { title: "MACD — Convergência/Divergência de Médias", text: "Compara uma média rápida e uma lenta para medir momentum. Cruzamento da linha MACD acima da linha de sinal indica força compradora ganhando espaço; abaixo, força vendedora. O histograma mostra a distância entre as duas linhas." },
  emasma: { title: "Médias Móveis (EMA/SMA)", text: "A EMA reage mais rápido que a SMA por dar mais peso aos candles recentes. Média rápida acima da lenta sugere viés de alta no curto prazo; abaixo, viés de baixa. Indicam direção, não o momento exato de entrada." },
  suporteresistencia: { title: "Suporte e Resistência", text: "Suporte é onde o preço historicamente para de cair; resistência, onde para de subir. Quanto mais vezes testado sem romper, mais relevante o nível tende a ser — mas todo nível pode ser rompido eventualmente." },
  candlestick: { title: "Padrões de Candlestick", text: "Engolfo, martelo, doji, estrela cadente mostram o resultado da disputa entre compradores e vendedores num candle. Ganham relevância perto de suporte/resistência ou após uma tendência longa." },
  tendencia: { title: "Tendência vs. Lateralização", text: "Tendência forma topos e fundos ascendentes (alta) ou descendentes (baixa). Mercado lateral oscila numa faixa. Indicadores de tendência (MACD, EMAs) tendem a funcionar melhor em tendência; RSI extremo tende a funcionar melhor em lateralização." },
  gestaoderisco: { title: "Gestão de Risco", text: "Defina antes de operar: % do capital por entrada (comumente 1-3%), quantas perdas seguidas fazem você parar no dia, e nunca aumente o valor pra 'recuperar' perda. Em opções binárias o risco por entrada é 100% do valor investido." },
  payout: { title: "Payout e Taxa de Acerto Mínima", text: "O pagamento em opções binárias é menor que 100%. Isso cria um piso matemático: com payout de 85%, é preciso acertar mais de 54% das entradas só para empatar no longo prazo. Payout menor exige taxa de acerto maior." },
  otc: { title: "Ativos OTC / Índices Sintéticos", text: "Pares OTC e índices como 'Stable Tick Index' costumam ser gerados pela própria corretora, especialmente fora do horário de mercado tradicional, e podem não acompanhar o preço real. Indicadores sobre dados reais servem como referência aproximada, não espelho exato." },
  psicologia: { title: "Psicologia de Trading", text: "Entrar no impulso após uma perda, aumentar valores de forma emocional, ou abandonar a estratégia após uma sequência de acertos são erros mais comuns que destroem contas do que a qualidade dos sinais em si." },
  priceaction: { title: "Price Action", text: "Analisar o preço e o formato dos candles diretamente, sem depender só de indicadores. Foca em estrutura de mercado, topos/fundos e o comportamento do preço ao testar uma região-chave." },
};

function ema(values, period) {
  const out = new Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  out[period - 1] = sum / period;
  for (let i = period; i < values.length; i++) out[i] = values[i] * k + out[i - 1] * (1 - k);
  return out;
}

function rsiCalc(values, period = 14) {
  const out = new Array(values.length).fill(null);
  if (values.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = values[i] - values[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  let avgGain = gain / period, avgLoss = loss / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    const g = d > 0 ? d : 0, l = d < 0 ? -d : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

function macdCalc(values) {
  const ema12 = ema(values, 12);
  const ema26 = ema(values, 26);
  const macdLine = values.map((_, i) => (ema12[i] != null && ema26[i] != null ? ema12[i] - ema26[i] : null));
  const firstValid = macdLine.findIndex((v) => v != null);
  let signalLine = new Array(values.length).fill(null);
  if (firstValid >= 0) {
    const sub = macdLine.slice(firstValid);
    const subSignal = ema(sub, 9);
    subSignal.forEach((v, i) => { signalLine[firstValid + i] = v; });
  }
  const hist = values.map((_, i) => (macdLine[i] != null && signalLine[i] != null ? macdLine[i] - signalLine[i] : null));
  return { macdLine, signalLine, hist };
}

function nextEntryTime(intervalMins) {
  const ms = intervalMins * 60000;
  const now = new Date();
  return new Date(Math.ceil(now.getTime() / ms) * ms);
}

function fmtClock(d) {
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
function fmtShort(d) {
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}
function parseTime(t) {
  return new Date(t.replace(" ", "T"));
}

function buildSignal(closes, rsiArr, emaFast, emaSlow, macdData) {
  const i = closes.length - 1;
  const lastRsi = rsiArr[i], lastFast = emaFast[i], lastSlow = emaSlow[i];
  const lastMacd = macdData.macdLine[i], lastSig = macdData.signalLine[i];
  if ([lastRsi, lastFast, lastSlow, lastMacd, lastSig].some((v) => v == null)) return null;

  let bull = 0, bear = 0;
  const reasons = [];

  if (lastRsi < 30) { bull++; reasons.push({ key: "rsi", side: "buy", text: `RSI em ${lastRsi.toFixed(1)} (sobrevenda)` }); }
  else if (lastRsi > 70) { bear++; reasons.push({ key: "rsi", side: "sell", text: `RSI em ${lastRsi.toFixed(1)} (sobrecompra)` }); }
  else reasons.push({ key: "rsi", side: "neutral", text: `RSI neutro em ${lastRsi.toFixed(1)}` });

  if (lastMacd > lastSig) { bull++; reasons.push({ key: "macd", side: "buy", text: "MACD acima da linha de sinal" }); }
  else { bear++; reasons.push({ key: "macd", side: "sell", text: "MACD abaixo da linha de sinal" }); }

  if (lastFast > lastSlow) { bull++; reasons.push({ key: "emasma", side: "buy", text: "EMA9 acima da EMA21" }); }
  else { bear++; reasons.push({ key: "emasma", side: "sell", text: "EMA9 abaixo da EMA21" }); }

  let direction = "AGUARDAR";
  if (bull >= 2 && bull > bear) direction = "COMPRA";
  else if (bear >= 2 && bear > bull) direction = "VENDA";
  const strength = Math.max(bull, bear);
  const confidence = strength === 3 ? "Alta" : strength === 2 ? "Média" : "Baixa";
  return { direction, confidence, reasons, bull, bear, lastRsi, lastMacd, lastSig };
}

const LS_KEY = "jarvis_trader_settings_v1";

function loadSettings() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) { /* ignore */ }
  return {};
}

export default function App() {
  const saved = loadSettings();
  const [apiKey, setApiKey] = useState(saved.apiKey || "220597cec0224bceb57c35c569b96e71");
  const [assetIdx, setAssetIdx] = useState(saved.assetIdx ?? 0);
  const [interval, setIntervalSel] = useState(saved.interval || "1min");
  const [candles, setCandles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(saved.autoRefresh ?? true);
  const [showSettings, setShowSettings] = useState(false);
  const [tab, setTab] = useState("dashboard");
  const [openTopic, setOpenTopic] = useState(null);
  const [payout, setPayout] = useState(ASSETS[saved.assetIdx ?? 0].payout);
  const [analysisAt, setAnalysisAt] = useState(null);
  const timerRef = useRef(null);

  const asset = ASSETS[assetIdx];
  const intervalObj = INTERVALS.find((iv) => iv.value === interval);

  useEffect(() => {
    localStorage.setItem(LS_KEY, JSON.stringify({ apiKey, assetIdx, interval, autoRefresh }));
  }, [apiKey, assetIdx, interval, autoRefresh]);

  const load = useCallback(async () => {
    if (!apiKey) { setError("Informe sua API key da Twelve Data."); return; }
    setLoading(true);
    setError(null);
    try {
      const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(asset.symbol)}&interval=${interval}&outputsize=100&apikey=${apiKey}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.status === "error" || !data.values) throw new Error(data.message || "Falha ao buscar dados (verifique a API key ou o limite de requisições).");
      const parsed = data.values
        .map((v) => ({ time: v.datetime, close: parseFloat(v.close) }))
        .reverse();
      setCandles(parsed);
      setLastUpdate(new Date());
      setAnalysisAt(new Date());
    } catch (e) {
      setError(e.message || "Erro desconhecido.");
    } finally {
      setLoading(false);
    }
  }, [apiKey, asset.symbol, interval]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (autoRefresh) {
      timerRef.current = setInterval(load, 60000);
      return () => clearInterval(timerRef.current);
    }
  }, [autoRefresh, load]);

  useEffect(() => { setPayout(asset.payout); }, [assetIdx]);

  const closes = candles.map((c) => c.close);
  const rsiArr = rsiCalc(closes, 14);
  const emaFast = ema(closes, 9);
  const emaSlow = ema(closes, 21);
  const macdData = macdCalc(closes);
  const signal = closes.length > 30 ? buildSignal(closes, rsiArr, emaFast, emaSlow, macdData) : null;

  const chartData = candles.slice(-40).map((c, idx, arr) => {
    const globalIdx = candles.length - arr.length + idx;
    return {
      time: fmtShort(parseTime(c.time)),
      close: c.close,
      ema9: emaFast[globalIdx],
      ema21: emaSlow[globalIdx],
    };
  });

  const macdChartData = candles.slice(-40).map((c, idx, arr) => {
    const globalIdx = candles.length - arr.length + idx;
    return {
      time: fmtShort(parseTime(c.time)),
      hist: macdData.hist[globalIdx],
      macd: macdData.macdLine[globalIdx],
      signal: macdData.signalLine[globalIdx],
    };
  });

  const entryTime = nextEntryTime(intervalObj.mins);
  const breakeven = (100 / (100 + Number(payout || 0))) * 100;

  const dirColor = signal?.direction === "COMPRA" ? C.buy : signal?.direction === "VENDA" ? C.sell : C.wait;
  const DirIcon = signal?.direction === "COMPRA" ? TrendingUp : signal?.direction === "VENDA" ? TrendingDown : Minus;

  const relevantTopics = signal
    ? Array.from(new Set(signal.reasons.map((r) => r.key))).concat(["gestaoderisco", "payout"])
    : ["rsi", "macd", "emasma", "gestaoderisco"];

  return (
    <div style={{ background: C.bg, color: C.text, minHeight: "100vh", fontFamily: "'Inter', system-ui, sans-serif" }} className="w-full p-4 pb-10">
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div style={{ background: C.accent }} className="w-9 h-9 rounded-md flex items-center justify-center font-bold text-black">J</div>
          <div>
            <div className="text-lg font-bold tracking-tight">JARVIS TRADER</div>
            <div style={{ color: C.muted }} className="text-xs">Dashboard de análise técnica · Twelve Data</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs" style={{ color: error ? C.sell : C.buy }}>
            {error ? <WifiOff size={14} /> : <Wifi size={14} />}
            {error ? "desconectado" : "conectado"}
          </div>
          <button onClick={load} disabled={loading} style={{ background: C.panel2, border: `1px solid ${C.border}` }} className="px-3 py-1.5 rounded-md text-xs flex items-center gap-1.5">
            <RefreshCw size={13} className={loading ? "animate-spin" : ""} /> Atualizar
          </button>
          <button onClick={() => setShowSettings((s) => !s)} style={{ background: C.panel2, border: `1px solid ${C.border}` }} className="p-1.5 rounded-md">
            <Settings2 size={15} />
          </button>
        </div>
      </div>

      {showSettings && (
        <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-lg p-4 mb-5 text-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="font-semibold">Configurações</span>
            <button onClick={() => setShowSettings(false)}><X size={15} /></button>
          </div>
          <label style={{ color: C.muted }} className="text-xs block mb-1">API key Twelve Data</label>
          <input
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            style={{ background: C.panel2, border: `1px solid ${C.border}`, color: C.text }}
            className="w-full rounded-md px-3 py-2 text-xs mb-2 font-mono"
          />
          <div style={{ color: C.wait }} className="text-xs flex items-start gap-1.5">
            <AlertTriangle size={13} className="mt-0.5 shrink-0" />
            Fica salva só no seu aparelho (armazenamento local do app).
          </div>
          <label className="flex items-center gap-2 mt-3 text-xs">
            <input type="checkbox" checked={autoRefresh} onChange={(e) => setAutoRefresh(e.target.checked)} />
            Atualizar automaticamente a cada 60s
          </label>
        </div>
      )}

      <div className="flex flex-wrap gap-2 mb-4">
        {ASSETS.map((a, i) => (
          <button
            key={a.symbol}
            onClick={() => setAssetIdx(i)}
            style={{
              background: i === assetIdx ? C.accent : C.panel2,
              color: i === assetIdx ? "#0A0D12" : C.text,
              border: `1px solid ${i === assetIdx ? C.accent : C.border}`,
            }}
            className="px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap"
          >
            {a.label}
          </button>
        ))}
      </div>
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div className="flex gap-1.5">
          {INTERVALS.map((iv) => (
            <button
              key={iv.value}
              onClick={() => setIntervalSel(iv.value)}
              style={{
                background: iv.value === interval ? C.panel2 : "transparent",
                border: `1px solid ${iv.value === interval ? C.accent : C.border}`,
                color: iv.value === interval ? C.accent : C.muted,
              }}
              className="px-3 py-1 rounded-md text-xs font-semibold"
            >
              {iv.label}
            </button>
          ))}
        </div>
        <div style={{ color: C.muted }} className="text-xs">
          {asset.broker} · payout sugerido {asset.payout}% · {lastUpdate ? `atualizado às ${fmtClock(lastUpdate)}` : "carregando..."}
        </div>
      </div>

      {error && (
        <div style={{ background: "#2A1316", border: `1px solid ${C.sell}`, color: C.sell }} className="rounded-lg p-3 mb-5 text-sm flex items-center gap-2">
          <AlertTriangle size={16} /> {error}
        </div>
      )}

      <div className="flex gap-4 mb-5" style={{ borderBottom: `1px solid ${C.border}` }}>
        {[{ id: "dashboard", label: "Dashboard" }, { id: "biblioteca", label: "Biblioteca de estudo" }].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            style={{
              color: tab === t.id ? C.text : C.muted,
              borderBottom: tab === t.id ? `2px solid ${C.accent}` : "2px solid transparent",
            }}
            className="pb-2 text-sm font-medium"
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "dashboard" ? (
        <div className="grid grid-cols-1 gap-4">
          <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-lg p-4">
            <div className="text-xs font-semibold mb-2" style={{ color: C.muted }}>PREÇO · EMA9 · EMA21</div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={chartData}>
                <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                <XAxis dataKey="time" stroke={C.muted} fontSize={10} />
                <YAxis stroke={C.muted} fontSize={10} domain={["auto", "auto"]} />
                <Tooltip contentStyle={{ background: C.panel2, border: `1px solid ${C.border}`, fontSize: 12 }} />
                <Line type="monotone" dataKey="close" stroke={C.text} dot={false} strokeWidth={1.5} />
                <Line type="monotone" dataKey="ema9" stroke={C.accent} dot={false} strokeWidth={1.2} />
                <Line type="monotone" dataKey="ema21" stroke={C.wait} dot={false} strokeWidth={1.2} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div style={{ background: C.panel, border: `1px solid ${dirColor}55` }} className="rounded-lg p-4">
            <div className="text-xs font-semibold mb-2" style={{ color: C.muted }}>SINAL ATUAL</div>
            {signal ? (
              <>
                <div className="flex items-center gap-2 mb-2">
                  <DirIcon size={26} style={{ color: dirColor }} />
                  <span className="text-2xl font-extrabold" style={{ color: dirColor }}>{signal.direction}</span>
                </div>
                <div className="text-xs mb-3" style={{ color: C.muted }}>Confiança: {signal.confidence} ({Math.max(signal.bull, signal.bear)}/3 indicadores)</div>
                <div className="flex flex-col gap-1.5">
                  {signal.reasons.map((r, idx) => (
                    <div key={idx} className="text-xs flex items-center gap-2">
                      <span style={{ color: r.side === "buy" ? C.buy : r.side === "sell" ? C.sell : C.muted }}>●</span>
                      {r.text}
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div style={{ color: C.muted }} className="text-sm">Aguardando dados suficientes ({closes.length}/30 candles)...</div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-lg p-4">
              <div className="text-xs font-semibold mb-2 flex items-center gap-1.5" style={{ color: C.muted }}><Clock size={13} /> HORÁRIO</div>
              <div className="text-xs flex justify-between mb-1">
                <span style={{ color: C.muted }}>Análise</span>
                <span className="font-mono">{analysisAt ? fmtClock(analysisAt) : "—"}</span>
              </div>
              <div className="text-xs flex justify-between">
                <span style={{ color: C.muted }}>Entrada</span>
                <span className="font-mono font-bold" style={{ color: C.accent }}>{fmtShort(entryTime)}</span>
              </div>
            </div>
            <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-lg p-4">
              <div className="text-xs font-semibold mb-2" style={{ color: C.muted }}>PISO (PAYOUT)</div>
              <input
                type="number"
                value={payout}
                onChange={(e) => setPayout(e.target.value)}
                style={{ background: C.panel2, border: `1px solid ${C.border}`, color: C.text }}
                className="w-14 rounded px-1.5 py-0.5 text-xs mb-1"
              />
              <span className="text-xs ml-1" style={{ color: C.muted }}>%</span>
              <div className="text-xs mt-1">
                Mín. <span className="font-bold" style={{ color: C.wait }}>{breakeven.toFixed(1)}%</span>
              </div>
            </div>
          </div>

          <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-lg p-4">
            <div className="text-xs font-semibold mb-2" style={{ color: C.muted }}>MACD (12, 26, 9)</div>
            <ResponsiveContainer width="100%" height={130}>
              <ComposedChart data={macdChartData}>
                <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                <XAxis dataKey="time" stroke={C.muted} fontSize={10} />
                <YAxis stroke={C.muted} fontSize={10} />
                <Tooltip contentStyle={{ background: C.panel2, border: `1px solid ${C.border}`, fontSize: 12 }} />
                <ReferenceLine y={0} stroke={C.border} />
                <Bar dataKey="hist" fill={C.accent} opacity={0.5} />
                <Line type="monotone" dataKey="macd" stroke={C.buy} dot={false} strokeWidth={1.3} />
                <Line type="monotone" dataKey="signal" stroke={C.sell} dot={false} strokeWidth={1.3} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          <div style={{ background: C.panel, border: `1px solid ${C.border}` }} className="rounded-lg p-4 flex gap-6 flex-wrap">
            <div>
              <div className="text-xs" style={{ color: C.muted }}>RSI (14)</div>
              <div className="text-xl font-bold" style={{ color: signal ? (signal.lastRsi > 70 ? C.sell : signal.lastRsi < 30 ? C.buy : C.text) : C.muted }}>
                {signal ? signal.lastRsi.toFixed(1) : "—"}
              </div>
            </div>
            <div>
              <div className="text-xs" style={{ color: C.muted }}>MACD</div>
              <div className="text-xl font-bold">{signal ? signal.lastMacd.toFixed(4) : "—"}</div>
            </div>
            <div>
              <div className="text-xs" style={{ color: C.muted }}>Sinal MACD</div>
              <div className="text-xl font-bold">{signal ? signal.lastSig.toFixed(4) : "—"}</div>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3">
          <div style={{ background: C.panel2, border: `1px solid ${C.accent}55` }} className="rounded-lg p-4 mb-2">
            <div className="text-sm font-semibold mb-1" style={{ color: C.accent }}>Relevante para a análise atual</div>
            <div className="text-xs" style={{ color: C.muted }}>Tópicos ligados ao último sinal gerado:</div>
          </div>
          {relevantTopics.map((key) => (
            <TopicCard key={key} topic={KNOWLEDGE[key]} open={openTopic === key} onToggle={() => setOpenTopic(openTopic === key ? null : key)} highlight />
          ))}
          <div className="text-xs mt-4 mb-1" style={{ color: C.muted }}>Demais tópicos</div>
          {Object.keys(KNOWLEDGE).filter((k) => !relevantTopics.includes(k)).map((key) => (
            <TopicCard key={key} topic={KNOWLEDGE[key]} open={openTopic === key} onToggle={() => setOpenTopic(openTopic === key ? null : key)} />
          ))}
        </div>
      )}

      <div style={{ borderTop: `1px solid ${C.border}`, color: C.muted }} className="mt-6 pt-4 text-xs leading-relaxed">
        Ferramenta educacional de apoio à análise técnica. Não é recomendação de investimento e não garante resultado. Opções binárias envolvem risco de perda total do valor investido em cada entrada. Pares OTC podem ser sintéticos e divergir do preço real mostrado aqui.
      </div>
    </div>
  );
}

function TopicCard({ topic, open, onToggle, highlight }) {
  return (
    <div style={{ background: C.panel, border: `1px solid ${highlight ? C.accent + "55" : C.border}` }} className="rounded-lg p-4">
      <button onClick={onToggle} className="w-full flex items-center justify-between text-left">
        <span className="flex items-center gap-2 text-sm font-medium">
          <BookOpen size={14} style={{ color: C.accent }} /> {topic.title}
        </span>
        {open ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
      </button>
      {open && <div className="text-xs mt-2 leading-relaxed" style={{ color: C.muted }}>{topic.text}</div>}
    </div>
  );
}
